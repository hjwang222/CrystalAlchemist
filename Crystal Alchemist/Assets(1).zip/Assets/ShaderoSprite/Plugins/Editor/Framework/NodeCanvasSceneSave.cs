﻿using UnityEngine;
using _ShaderoShaderEditorFramework;

public class NodeCanvasSceneSave : MonoBehaviour 
{
	public NodeCanvas savedNodeCanvas;
}
