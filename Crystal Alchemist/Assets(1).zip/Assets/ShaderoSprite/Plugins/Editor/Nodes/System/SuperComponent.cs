using UnityEngine;
using System.Collections;
using _ShaderoShaderEditorFramework;
using _ShaderoShaderEditorFramework.Utilities;


public class SuperFloat : Component
{
    public string StringPreviewLines;
    public string ValueLine;
    public string StringPreviewNew;
    public string Result;
    public string ParametersLines;
    public string ParametersDeclarationLines;
}
public class SuperFloat2 : Component
{
    public string StringPreviewLines;
    public string ValueLine;
    public string StringPreviewNew;
    public string Result;
    public string ParametersLines;
    public string ParametersDeclarationLines;
}

public class SuperFloat4 : Component
{
    public string StringPreviewLines;
    public string ValueLine;
    public string StringPreviewNew;
    public string Result;
    public string ParametersLines;
    public string ParametersDeclarationLines;
}
public class SuperSource : Component
{
    public string StringPreviewLines;
    public string ValueLine;
    public string StringPreviewNew;
    public string Result;
    public string ParametersLines;
    public string ParametersDeclarationLines;
}
