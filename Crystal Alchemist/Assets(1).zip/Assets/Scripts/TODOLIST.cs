﻿using UnityEngine;

public class TODOLIST : MonoBehaviour
{
    //Wetter
    //- Regen (x)
    //- Schnee (x)
    //- Gewitter
    //- Nebel
    //- Wolken

    //- Grau
    //- Wüste
    //- Unterwasser

    //Destroy Handler?
    //FIXES (0.2.4.0)
    //- Options Rework (Resolution)
    //- Input Rework (new Unity Feature)
    //- Clunky Button und Cursor (all Menues)

    //TODO (0.2.4.5):
    //- Wetter Script (Position und Größe)
    //- Charakter Creator
    //- Savegames (3)
    //- Bosskampf (Titania)
}
