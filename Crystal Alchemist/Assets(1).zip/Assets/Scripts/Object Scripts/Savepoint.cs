﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Sirenix.OdinInspector;

public class Savepoint : Interactable
{
    public override void doSomethingOnSubmit()
    {
        Scene scene = SceneManager.GetActiveScene();

        SaveSystem.Save(this.player, scene.name);

        this.player.GetComponent<PlayerTeleport>().setLastTeleport(scene.name, this.player.transform.position);

        CustomUtilities.DialogBox.showDialog(this, this.player);
    }
}
